//
//  ViewController.swift
//  Simplified Calculator
//
//  Created by Lab1422 on 2022/3/21.
//

import UIKit

extension NSExpression {
    var floatifiedForDivisionIfNeeded: NSExpression {
        if function == "divide:by:", let args = arguments, let last = args.last,
          let firstValue = args.first?.constantValue as? NSNumber {
            let newFirst = NSExpression(forConstantValue: firstValue.doubleValue)
            return NSExpression(forFunction: function, arguments: [newFirst, last])
        } else {
            return self
        }
    }
}
class ViewController: UIViewController {
    
    @IBOutlet weak var plus: UIButton!
    @IBOutlet weak var sub: UIButton!
    @IBOutlet weak var product: UIButton!
    @IBOutlet weak var divide: UIButton!
    @IBOutlet weak var percent: UIButton!
    
    @IBOutlet weak var clearB: UIButton!
    @IBOutlet weak var showCal: UILabel!
    @IBOutlet weak var typing: UILabel!
    
    var useSym: Bool = true
    var useClear: Bool = false
    var useDot: Bool = true
    var usedEqual: Bool = false
    var usedNegBtn: Bool = false
    var lastSymbolPosition: String.Index?
    
    @IBAction func numbers(_ sender: UIButton) {
        let inputNum = sender.tag - 1
        if typing.text == "0" || usedEqual==true{
            typing.text = "\(inputNum)"
            
        }
        else if typing.text == "-0"{
            typing.text = "-\(inputNum)"
        }
        else{
            typing.text = typing.text! + "\(inputNum)"
        }
        
        let i = showCal.text!.index(before: showCal.text!.endIndex)
        if (showCal.text == "0")||(usedEqual){
            showCal.text = "\(inputNum)"
        }
        else if showCal.text![i]=="0" && (showCal.text![showCal.text!.index(before: i)]=="+" || showCal.text![showCal.text!.index(before: i)]=="-" || showCal.text![showCal.text!.index(before: i)]=="*" || showCal.text![showCal.text!.index(before: i)]=="/" || showCal.text![showCal.text!.index(before: i)]=="%"){
            let range = showCal.text!.startIndex..<i
            showCal.text = String(showCal.text![range]) + "\(inputNum)"
            
        }
        else{
            showCal.text = showCal.text! + "\(inputNum)"
        }
        useSym = true
        useClear = false
        usedEqual = false
        clearB.setTitle("C", for: UIControl.State.normal)
        
        plus.setTitleColor(#colorLiteral(red: 0.2846056521, green: 0.6188198328, blue: 0.9838333726, alpha: 1), for: UIControl.State.normal)
        plus.backgroundColor = #colorLiteral(red: 0.5937761664, green: 0.7700536847, blue: 0.7197963595, alpha: 1)
        sub.setTitleColor(#colorLiteral(red: 0.2846056521, green: 0.6188198328, blue: 0.9838333726, alpha: 1), for: UIControl.State.normal)
        sub.backgroundColor = #colorLiteral(red: 0.5937761664, green: 0.7700536847, blue: 0.7197963595, alpha: 1)
        product.setTitleColor(#colorLiteral(red: 0.2846056521, green: 0.6188198328, blue: 0.9838333726, alpha: 1), for: UIControl.State.normal)
        product.backgroundColor = #colorLiteral(red: 0.5937761664, green: 0.7700536847, blue: 0.7197963595, alpha: 1)
        divide.setTitleColor(#colorLiteral(red: 0.2846056521, green: 0.6188198328, blue: 0.9838333726, alpha: 1), for: UIControl.State.normal)
        divide.backgroundColor = #colorLiteral(red: 0.5937761664, green: 0.7700536847, blue: 0.7197963595, alpha: 1)
        percent.setTitleColor(#colorLiteral(red: 0.2846056521, green: 0.6188198328, blue: 0.9838333726, alpha: 1), for: UIControl.State.normal)
        percent.backgroundColor = #colorLiteral(red: 0.5937761664, green: 0.7700536847, blue: 0.7197963595, alpha: 1)
    }
    
    
    @IBAction func symbol(_ sender: UIButton) {
        print(useSym)
        let ct = sender.currentTitle
        if useSym==true{
            if usedNegBtn{
                showCal.text = showCal.text! + ")"
            }
            showCal.text = showCal.text! + ct!
            lastSymbolPosition = showCal.text!.index(before: showCal.text!.endIndex)
            showCal.text = showCal.text! + "0"
            typing.text = "0"
            useSym = false
            useDot = true
            usedNegBtn = false
            usedEqual = false
        }
        else{
            let pos = lastSymbolPosition ?? showCal.text!.startIndex
            switch showCal.text![pos]{
                case "+", "-", "*", "/", "%":
                showCal.text!.removeSubrange(lastSymbolPosition!..<showCal.text!.endIndex)
                    showCal.text = showCal.text! + ct! + "0"
                default: break
            }
            useSym = false
            
            plus.setTitleColor(#colorLiteral(red: 0.2846056521, green: 0.6188198328, blue: 0.9838333726, alpha: 1), for: UIControl.State.normal)
            plus.backgroundColor = #colorLiteral(red: 0.5937761664, green: 0.7700536847, blue: 0.7197963595, alpha: 1)
            sub.setTitleColor(#colorLiteral(red: 0.2846056521, green: 0.6188198328, blue: 0.9838333726, alpha: 1), for: UIControl.State.normal)
            sub.backgroundColor = #colorLiteral(red: 0.5937761664, green: 0.7700536847, blue: 0.7197963595, alpha: 1)
            product.setTitleColor(#colorLiteral(red: 0.2846056521, green: 0.6188198328, blue: 0.9838333726, alpha: 1), for: UIControl.State.normal)
            product.backgroundColor = #colorLiteral(red: 0.5937761664, green: 0.7700536847, blue: 0.7197963595, alpha: 1)
            divide.setTitleColor(#colorLiteral(red: 0.2846056521, green: 0.6188198328, blue: 0.9838333726, alpha: 1), for: UIControl.State.normal)
            divide.backgroundColor = #colorLiteral(red: 0.5937761664, green: 0.7700536847, blue: 0.7197963595, alpha: 1)
            percent.setTitleColor(#colorLiteral(red: 0.2846056521, green: 0.6188198328, blue: 0.9838333726, alpha: 1), for: UIControl.State.normal)
            percent.backgroundColor = #colorLiteral(red: 0.5937761664, green: 0.7700536847, blue: 0.7197963595, alpha: 1)
        }
        sender.setTitleColor(UIColor.white, for: UIControl.State.normal)
        sender.backgroundColor = UIColor.blue
        
    }
    
    @IBAction func Dot(_ sender: UIButton) {
        if useDot{
            if usedEqual{
                typing.text = "0."
                showCal.text = "0."
                useSym = false
            }
            else{
                typing.text = typing.text! + "."
                showCal.text = showCal.text! + "."
            }
            useDot = false
        }
    }
    
    @IBAction func negBtn(_ sender: Any) {
        if !usedNegBtn{
            if let pos = lastSymbolPosition{
                let range = showCal.text!.index(after: pos)..<showCal.text!.endIndex
                let tempString = showCal.text![range]
                showCal.text!.removeSubrange(range)
                showCal.text = showCal.text! + "(-" + tempString
                
            }
            else{
                showCal.text = "(-" + showCal.text!
            }
            typing.text = "-" + typing.text!
            usedNegBtn = true
        }
        else{
            if let pos = lastSymbolPosition{
                let range = showCal.text!.index(after: pos)..<showCal.text!.endIndex
                var tempString = showCal.text![range]
                tempString.removeSubrange(tempString.startIndex...tempString.index(after: tempString.startIndex))
                showCal.text!.removeSubrange(range)
                showCal.text = showCal.text! + tempString
            }
            else{
                showCal.text!.removeFirst()
                showCal.text!.removeFirst()
            }
            typing.text!.removeFirst()
            usedNegBtn = false
        }
    }
    
    
    @IBAction func clear(_ sender: UIButton) {
        if showCal.text == "0"{
            showCal.text = "0"
            typing.text = "0"
        }
        else if useClear == false{
            if let pos = lastSymbolPosition{
                let tempSymbol = showCal.text![pos]
                
                showCal.text!.removeSubrange(pos..<showCal.text!.endIndex)
                useSym = true
                print(tempSymbol)
                switch tempSymbol{
                case "+": symbol(plus)
                case "-": symbol(sub)
                case "*": symbol(product)
                case "/": symbol(divide)
                case "%": symbol(percent)
                default: break
                }
            }
            else{
                typing.text = "0"
                showCal.text = "0"
            }
            
            useClear = true
        }
        else{
            showCal.text = "0"
            lastSymbolPosition = nil
            useClear = false
        }
        sender.setTitle("AC", for: UIControl.State.normal)
        useDot = true
        usedNegBtn = false
    }
    @IBAction func equalTo(_ sender: UIButton) {
        if lastSymbolPosition != nil{
            if usedNegBtn{
                showCal.text = showCal.text! + ")"
            }
            let checkPercent = showCal.text!.replacingOccurrences(of: "%", with: "*0.01")
            let expression = NSExpression(format: checkPercent).floatifiedForDivisionIfNeeded
            let result = expression.expressionValue(with: nil, context: nil) as! Double
            print(result)
            let resultString = formatResult(result: result)
            typing.text = resultString
            showCal.text = resultString
            usedNegBtn = false
        }
        
        usedEqual = true
        clearB.setTitle("AC", for: UIControl.State.normal)
        useDot = true
        lastSymbolPosition = nil
        
    }
    
    func formatResult(result: Double) -> String
    {
        if result != 0{
            if(result.truncatingRemainder(dividingBy: 1.0) == 0.0)||((result*(-1)).truncatingRemainder(dividingBy: 1.0)==0.0)
            {
                return String(format: "%.0f", result)
            }
            else if((result*10).truncatingRemainder(dividingBy: 1.0)==0.0)||((result*(-10)).truncatingRemainder(dividingBy: 1.0)==0.0)
            {
                return String(format: "%.1f", result)
            }
            else if((result*100).truncatingRemainder(dividingBy: 1.0)==0.0)||((result*(-100)).truncatingRemainder(dividingBy: 1.0)==0.0)
            {
                return String(format: "%.2f", result)
            }
            else if((result*1000).truncatingRemainder(dividingBy: 1.0)==0.0)||((result*(-1000)).truncatingRemainder(dividingBy: 1.0)==0.0)
            {
                return String(format: "%.3f", result)
            }
            else if((result*10000).truncatingRemainder(dividingBy: 1.0)==0.0)||((result*(-10000)).truncatingRemainder(dividingBy: 1.0)==0.0)
            {
                return String(format: "%.4f", result)
            }
            else if((result*100000).truncatingRemainder(dividingBy: 1.0)==0.0)||((result*(-100000)).truncatingRemainder(dividingBy: 1.0)==0.0)
            {
                return String(format: "%.5f", result)
            }
            else if((result*1000000).truncatingRemainder(dividingBy: 1.0)==0.0)||((result*(-1000000)).truncatingRemainder(dividingBy: 1.0)==0.0)
            {
                return String(format: "%.6f", result)
            }
            else if((result*10000000).truncatingRemainder(dividingBy: 1.0)==0.0)||((result*(-10000000)).truncatingRemainder(dividingBy: 1.0)==0.0)
            {
                return String(format: "%.7f", result)
            }
            else if((result*100000000).truncatingRemainder(dividingBy: 1.0)==0.0)||((result*(-100000000)).truncatingRemainder(dividingBy: 1.0)==0.0)
            {
                return String(format: "%.8f", result)
            }
            else
            {
                return String(format: "%.10f", result)
            }
        }
        else{
            return "0"
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

